class Exposicion {
    private int idExposicion;
    private String nombreExposicion;
    private String direccionExposicion;

    public Exposicion(int idExposicion, String nombreExposicion, String direccionExposicion) {
        this.idExposicion = idExposicion;
        this.nombreExposicion = nombreExposicion;
        this.direccionExposicion = direccionExposicion;
    }

    public int getIdExposicion() {
        return idExposicion;
    }

    public String getNombreExposicion() {
        return nombreExposicion;
    }

    public String getDireccionExposicion() {
        return direccionExposicion;
    }
}

