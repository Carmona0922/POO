class Reparacion {
    private int idReparacion;
    private int idCarro;
    private String tipo;
    private double costo;
    private String descripcion;

    public Reparacion(int idReparacion, int idCarro, String tipo, double costo, String descripcion) {
        this.idReparacion = idReparacion;
        this.idCarro = idCarro;
        this.tipo = tipo;
        this.costo = costo;
        this.descripcion = descripcion;
    }

    public int getIdReparacion() {
        return idReparacion;
    }

    public int getIdCarro() {
        return idCarro;
    }

    public String getTipoReparacion() {
        return tipo;
    }

    public double getCostoReparacion() {
        return costo;
    }

    public String getDescripcion() {
        return descripcion;
    }
}