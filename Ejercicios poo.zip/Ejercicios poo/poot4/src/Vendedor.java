class Vendedor {
    private int idVendedor;
    private String nombre;
    private String direccion;
    private String tipoVendedor;
    private double salario;

    public Vendedor(int idVendedor, String nombre, String direccion, String tipoVendedor, double salario) {
        this.idVendedor = idVendedor;
        this.nombre = nombre;
        this.direccion = direccion;
        this.tipoVendedor = tipoVendedor;
        this.salario = salario;
    }

    public int getIdVendedor() {
        return idVendedor;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getTipoVendedor() {
        return tipoVendedor;
    }

    public double getSalario() {
        return salario;
    }
}

