class Proveedor {
    private int idProveedor;
    private String nombre;
    private String direccion;

    public Proveedor(int idProveedor, String nombre, String direccion) {
        this.idProveedor = idProveedor;
        this.nombre = nombre;
        this.direccion = direccion;
    }

    public int getIdProveedor() {
        return idProveedor;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }
}
