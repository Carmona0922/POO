class Carro {
    private int idCarro;
    private String marca;
    private String modelo;
    private String matricula;
    private double valor;
    private double costo;
    private String tipoCarro;
    private Proveedor proveedor;
    private Exposicion exposicion;

    public Carro(int idCarro, String marca, String modelo, String matricula, double valor, double costo,
                 String tipoCarro, Proveedor proveedor, Exposicion exposicion) {
        this.idCarro = idCarro;
        this.marca = marca;
        this.modelo = modelo;
        this.matricula = matricula;
        this.valor = valor;
        this.costo = costo;
        this.tipoCarro = tipoCarro;
        this.proveedor = proveedor;
        this.exposicion = exposicion;
    }

    public int getIdCarro() {
        return idCarro;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getMatricula() {
        return matricula;
    }

    public double getValor() {
        return valor;
    }

    public double getCosto() {
        return costo;
    }

    public String getTipoCarro() {
        return tipoCarro;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public Exposicion getExposicion() {
        return exposicion;
    }
}


